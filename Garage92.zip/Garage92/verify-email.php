<?php
session_start();

if (isset($_SESSION["sid"])) {
    header("location: index.php");
    exit;
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>GARAGE92 | Email Verification</title>
    <link href="img/favicon.ico" rel="icon">
    <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    <link href="css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css" integrity="sha384-DyZ88mC6Up2uqS4h/KRgHuoeGwBcD4Ng9SiP4dIRy0EXTlnuz47vAwmeGwVChigm" crossorigin="anonymous">
</head>

<body>
    <?php include_once('includes/header.php'); ?>
    <div class="container-fluid h-custom mt-5">
        <div class="row d-flex justify-content-center align-items-center h-100">
            <?php
            if ($_GET['key'] && $_GET['token']) {
                require "./includes/config.php";
                $email = $_GET['key'];
                $token = $_GET['token'];
                $query = mysqli_query(
                    $conn,
                    "SELECT * FROM `tbluser` WHERE `email_verification_link`='" . $token . "' and `email`='" . $email . "';"
                );
                $d = date('Y-m-d H:i:s');
                if (mysqli_num_rows($query) > 0) {
                    $row = mysqli_fetch_array($query);
                    if ($row['email_verified_at'] == NULL) {
                        mysqli_query($conn, "UPDATE tbluser set email_verified_at ='" . $d . "' WHERE email='" . $email . "'");
                        $msg = "Congratulations! Your email has been verified.";
                    } else {
                        $msg = "You have already verified your account with us";
                    }
                } else {
                    $msg = "This email has been not registered with us";
                }
            } else {
                $msg = "Your Something went wrong.";
            }
            ?>
            <div class="container mt-3">
                <div class="card">
                    <div class="card-header text-center">
                        Email Verification
                    </div>
                    <div class="card-body">
                        <p><?php echo $msg; ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>

    <?php include_once('includes/footer.php'); ?>

    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="js/main.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>

</html>