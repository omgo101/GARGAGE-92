<?php
session_start();

if (!isset($_SESSION['sid'])) {
    header('location: login.php');
}


require "./includes/config.php";

$old_password = $new_password = $confirm_password = "";
$old_password_err = $new_password_err = $confirm_password_err = "";


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (empty(trim($_POST["new_password"]))) {
        $new_password_err = "Please enter the new password.";
    } elseif (strlen(trim($_POST["new_password"])) < 6) {
        $new_password_err = "Password must have atleast 6 characters.";
    } else {
        $new_password = trim($_POST["new_password"]);
    }

    if (empty(trim($_POST["confirm_password"]))) {
        $confirm_password_err = "Please confirm the password.";
    } else {
        $confirm_password = trim($_POST["confirm_password"]);
        if (empty($new_password_err) && ($new_password != $confirm_password)) {
            $confirm_password_err = "Password did not match.";
        }
    }


    if (empty(trim($_POST["old_password"]))) {
        $old_password_err = "Please enter the old password.";
    } elseif (strlen(trim($_POST["old_password"])) < 6) {
        $old_password_err = "Password must have atleast 6 characters.";
    }
        if ($new_password_err == "" && $confirm_password_err == "" && $old_password_err == "") {
            $old_password = trim($_POST["old_password"]);
            $sql = "SELECT ID,Password FROM tbluser WHERE Email = ?";

            if ($stmt = mysqli_prepare($conn, $sql)) {

                mysqli_stmt_bind_param($stmt, "s", $param_email);


                $param_email = $_SESSION['email'];


                if (mysqli_stmt_execute($stmt)) {

                    mysqli_stmt_store_result($stmt);


                    if (mysqli_stmt_num_rows($stmt) == 1) {

                        mysqli_stmt_bind_result($stmt, $id, $password,);

                        if (mysqli_stmt_fetch($stmt)) {
                            if (password_verify($old_password, $password)) {

                                $sql = "UPDATE tbluser SET Password = ? WHERE id = ?";

                                if ($stmt = mysqli_prepare($conn, $sql)) {

                                    mysqli_stmt_bind_param($stmt, "si", $param_password, $param_id);

                                    $param_password = password_hash($new_password, PASSWORD_DEFAULT);
                                    $param_id = $_SESSION["sid"];

                                    if (mysqli_stmt_execute($stmt)) {
                                        session_destroy();
                                        header("location: login.php");
                                        exit();
                                    } else {
                                        $msg = "Oops! Something went wrong. Please try again later.";
                                    }
                                    mysqli_stmt_close($stmt);
                                }
                            } else {

                                $msg = "Incorrect Password";
                                $new_password = "";
                                $old_password = "";

                            }
                        }
                    } else {

                        $msg = "Something Went Wrong.";
                    }
                } else {
                    $msg = "Oops! Something went wrong. Please try again later.";
                }
            }
        }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>GARAGE92 | Update Password</title>
    <link href="img/favicon.ico" rel="icon">
    <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    <link href="./css/style.css" rel="stylesheet">
</head>

<body>
    <?php include_once('./includes/header.php'); ?>


    <div class="wrapper mt-5 mr-5 ml-5">
        <h2>Reset Password</h2>
        <p>Please fill out this form to reset your password.</p>
  <p style="font-size:16px; color:red" align="center">
                                                        <?php if (!empty($msg)) {
                                                            echo $msg;
                                                        }  ?> </p>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group">
                <label>Current Password</label>
                <input type="password" name="old_password" class="form-control <?php echo (!empty($old_password_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $old_password; ?>">
                <span class="invalid-feedback"><?php echo $old_password_err; ?></span>
            </div>
            <div class="form-group">
                <label>New Password</label>
                <input type="password" name="new_password" class="form-control <?php echo (!empty($new_password_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $new_password; ?>">
                <span class="invalid-feedback"><?php echo $new_password_err; ?></span>
            </div>
            <div class="form-group">
                <label>Confirm Password</label>
                <input type="password" name="confirm_password" class="form-control <?php echo (!empty($confirm_password_err)) ? 'is-invalid' : ''; ?>">
                <span class="invalid-feedback"><?php echo $confirm_password_err; ?></span>
            </div>
            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Submit">
                <a class="btn btn-link ml-2" href="login.php">Cancel</a>
            </div>
        </form>
    </div>

    <?php include_once('./includes/footer.php'); ?>

    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="./js/main.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>

</html>