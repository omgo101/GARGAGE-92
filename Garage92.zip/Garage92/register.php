<?php

session_start();
require "./includes/config.php";


$nameString = $emails = $password = $confirm_password = $errMsg = "";
$name_err = $email_err = $password_err = $confirm_password_err = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {


  $mobno = $_POST['mobile'];

  $regex = '/^[a-zA-Z\s]*$/';

  $nameString = $_POST['name'];

  if (preg_match($regex, $nameString)) {
    $name = trim($_POST['name']);
  } else {
    $name_err = "Only alphabets and whitespace are allowed.";
  }



  if (empty(trim($_POST["emails"]))) {
    $email_err = "Please enter a email.";
  } elseif (!filter_var($_POST["emails"], FILTER_VALIDATE_EMAIL)) {
    $email_err = "Invalid email format.";
    $errMsg = "Invalid email format";
  } else {
    $sql = "SELECT * FROM tbluser Where Email = ? && MobileNo = ?";

    if ($stmt = mysqli_prepare($conn, $sql)) {
      mysqli_stmt_bind_param($stmt, "si", $param_email, $mobno);

      $param_email = trim($_POST["emails"]);
      $param_mobno = $_POST['mobile'];

      if (mysqli_stmt_execute($stmt)) {
        mysqli_stmt_store_result($stmt);
        if (mysqli_stmt_num_rows($stmt) == 1) {
          $email_err = "This email or mobile Number already exists.";
        } else {
          $emails = trim($_POST["emails"]);
        }
      } else {
        $errMsg = "Oops! Something went wrong. Please try again later.";
      }

      mysqli_stmt_close($stmt);
    }
  }

  if (empty(trim($_POST["password"]))) {
    $password_err = "Please enter a password.";
    $errMsg = "Please enter a password.";
  } elseif (strlen(trim($_POST["password"])) < 6) {
    $password_err = "Password must have atleast 6 characters.";
    $errMsg = "Password must have atleast 6 characters.";
  } else {
    $password = trim($_POST["password"]);
  }

  if (empty(trim($_POST["confirm-password"]))) {
    $confirm_password_err = "Please confirm password.";
  } else {
    $confirm_password = trim($_POST["confirm-password"]);
    if (empty($password_err) && ($password != $confirm_password)) {
      $confirm_password_err = "Password did not match.";
      $errMsg = "Password did not match.";
    }
  }

  if ($errMsg == "" && $name_err == "" && $email_err == "" && $password_err == "" && $confirm_password_err == "") {

    $token = md5($emails) . rand(10, 9999);
    $link = "<a href='" . $url . "verify-email.php?key=" . $emails . "&token=" . $token . "'>Click and Verify Email</a>";
    require_once('./includes/email.php');

    $mail->FromName = 'GARAGE92';
    $mail->AddAddress($emails);
    $mail->Subject  =  'Reset Password';
    $mail->IsHTML(true);
    $mail->Body    = 'Click On This Link to Verify Email ' . $link . '';
    if ($mail->Send()) {
      $email_veri = "Check Your Email box and Click on the email verification link.";
    } else {
      $errMsg = "Mail Error - >" . $mail->ErrorInfo;
    }

    $sql = "INSERT INTO tbluser (FullName, MobileNo, Email, Password, email_verification_link) VALUES(?, ?, ?, ?, ?)";


    if ($stmt = mysqli_prepare($conn, $sql)) {

      $param_email = $emails;
      $param_mobno = $_POST['mobile'];
      $param_password = password_hash($password, PASSWORD_DEFAULT);
      mysqli_stmt_bind_param($stmt, "sisss", $name, $param_mobno, $param_email, $param_password, $token);

      if (mysqli_stmt_execute($stmt)) {
        header("refresh:5 ;url = login.php");
      } else {
        $errMsg = "Oops! Something went wrong. Please try again later.";
      }

      mysqli_stmt_close($stmt);
    }
  }

  mysqli_close($conn);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <title>GARAGE92 | SignUp Page</title>
  <link href="img/favicon.ico" rel="icon">
  <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
  <link href="css/style.css" rel="stylesheet">
</head>

<body>
  <?php include_once('includes/header.php'); ?>

  <?php
  if (!empty($errMsg)) {
    echo '<div class="alert alert-danger">' . $errMsg . '</div>';
  }
  ?>
  <?php
  if (!empty($email_veri)) {
    echo '<div class="alert alert-warning">' . $email_veri . '</div>';
  }
  ?>
  <div class="container-fluid h-custom">
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class="col-md-9 col-lg-6 col-xl-5">
        <img src="https://mdbootstrap.com/img/Photos/new-templates/bootstrap-login-form/draw2.png" class="img-fluid d-none d-lg-block d-xxl-none d-xxl-block" alt="Sample image">
      </div>
      <div class="col-md-8 col-lg-6 col-xl-4 offset-xl-1 mt-4">

        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" name="submit" method="post">

          <div class="form-group form-outline mb-4">
            <label class="form-label" for="name">Name:</label>
            <input type="text" name="name" id="name" class="form-control form-control-mg <?php echo (!empty($name_err)) ? 'is-invalid' : ''; ?>" placeholder="Full Name" required />
            <span class="invalid-feedback"><?php echo $name_err;?></span>
          </div>

          <div class="form-group form-outline mb-4">
            <label class="form-label" for="mobile">Mobile Number:</label>
            <input type="tel" name="mobile" id="mobile" class="form-control form-control-mg <?php echo (!empty($mobile_err)) ? 'is-invalid' : ''; ?>" placeholder="Mobile Number" pattern="[0-9]{10}" maxlength="10" required />
            <span class="invalid-feedback"><?php echo $mobile_err; ?></span>
          </div>

          <div class="form-group form-outline mb-4">
            <label class="form-label" for="emails">Email:</label>
            <input type="email" name="emails" id="emails" class="form-control form-control-mg <?php echo (!empty($email_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $emails; ?> " placeholder="Email Address" required />
            <span class="invalid-feedback"><?php echo $email_err; ?></span>
          </div>

          <div class="form-group">
            <div class="form-group form-outline mb-3">
              <label class="form-label" for="password">Password:</label>
              <input type="password" name="password" id="password" class="form-control form-control-mg <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?>" pattern=".{6,}" title="More than 6 characters allowed" placeholder="Enter password" required />
              <span class="invalid-feedback"><?php echo $password_err; ?></span>
            </div>

            <div class="form-group form-outline mb-3">
              <label class="form-label" for="confirm-password">Confirm Password:</label>
              <input type="password" name="confirm-password" id="confirm-password" class="form-control form-control-mg <?php echo (!empty($confirm_password_err)) ? 'is-invalid' : ''; ?>" pattern=".{6,}" title="More than 6 characters allowed" placeholder="Confirm password" required />
              <span class="invalid-feedback"><?php echo $confirm_password_err; ?></span>
            </div>
          </div>

          <div class="text-center text-lg-start mt-4 pt-2 mb-4 rounded">
            <input type="submit" class="btn btn-primary btn-lg" style="padding-left: 2.5rem; padding-right: 2.5rem;" name="submit" value="Sign Up">
          </div>

          <div>
            <p>Already have an account? <a href="login.php">Login here</a>.</p>
          </div>

        </form>
      </div>
    </div>
  </div>

  <?php include_once('includes/footer.php'); ?>

  <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script>
  <script src="lib/waypoints/waypoints.min.js"></script>
  <script src="js/main.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>

</html>