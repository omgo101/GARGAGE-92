<?php
// U can enter IP address in url
$url = "localhost/Garage92/";
define('DB_HOST','localhost');
define('DB_USER','root');
define('DB_PASS','');
define('DB_NAME','Garage92');
?>