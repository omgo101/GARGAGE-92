<div class="footer">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-md-6">
                    <div class="footer-contact">
                            <h2>Get In Touch</h2>

                            <p><i class="fa fa-map-marker-alt"></i>Cabesa Ward, St Cruz, Goa 403202</p>
                            <p><i class="fa fa-phone-alt"></i>+91 9511864023</p>
                            <p><i class="fa fa-envelope"></i><a style="text-decoration: none; color: white;" href="mailto:garage.9ne2@gmail.com">garage.9ne2@gmail.com</a></p>

                                                    <div class="footer-social">
                                                    <a class="btn" href="https://www.facebook.com/garage92goa/"><i class="fab fa-facebook-f"></i></a>
                                <a class="btn" href="https://www.youtube.com/channel/UCpxClZevvllxb3tPS7zBr2w/"><i class="fab fa-youtube"></i></a>
                                <a class="btn" href="https://www.instagram.com/garage92.goa/"><i class="fab fa-instagram"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-5 col-md-6">
                        <div class="footer-link">
                            <h2>Popular Links</h2>
                            <a href="index.php">Home</a>
                            <a href="about.php">About Us</a>
                            <a href="get-appointment.php">Service Booking</a>
                        </div>
                    </div>
             
                </div>
            </div>
        </div>

        <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>
