<?php
session_start();

if (isset($_SESSION["sid"])) {
  header("location: ./index.php");
  exit;
}

if (isset($_POST['password']) && $_POST['reset_link_token'] && $_POST['email']) {
  require("../includes/config.php");

  $emailId = $_POST['email'];
  $token = $_POST['reset_link_token'];

  if ($_POST['password'] == $_POST['cpassword']) {
    $pass = $_POST['password'];
    $password = password_hash($pass, PASSWORD_DEFAULT);

    $query = mysqli_query($conn, "SELECT * FROM `tbluser` WHERE `reset_link_token`='" . $token . "' and `email`='" . $emailId . "'");
    $row = mysqli_num_rows($query);
    if ($row) {
      mysqli_query($conn, "UPDATE `tbluser` set `Password`='" . $password . "', reset_link_token=null ,exp_date=null WHERE email='" . $emailId . "'");
      echo "<script>alert(Congratulations! Your password has been updated successfully.);</script>";
      echo "<script>window.location.href ='../login.php'</script>";
    } else {
      echo "<script>alert(Something gone wrong. Please try again.);</script>";
      echo "<script>window.location.href = '../index.php'</script>";
    }
  }else{
    echo "<script>alert(Password Does not Match);</script>";
      echo "<script>window.location.href = '../index.php'</script>";
  }
}