<?php
session_start();

if (isset($_SESSION["sid"])) {
  header("location: index.php");
  exit;
}

require "./includes/config.php";


$emails = $password_lg = "";
$email_err = $password_err = $login_err = "";


if ($_SERVER["REQUEST_METHOD"] == "POST") {


  if (empty(trim($_POST["email"]))) {
    $email_err = "Please enter email.";
  } else {
    $emails = trim($_POST["email"]);
  }


  if (empty(trim($_POST["password"]))) {
    $password_err = "Please enter your password.";
  } else {
    $password_lg = trim($_POST["password"]);
  }


  if (empty($email_err) && empty($password_err)) {

    $sql = "SELECT ID, Email, Password,email_verified_at FROM tbluser WHERE Email = ?";

    if ($stmt = mysqli_prepare($conn, $sql)) {

      mysqli_stmt_bind_param($stmt, "s", $param_email);


      $param_email = $emails;


      if (mysqli_stmt_execute($stmt)) {

        mysqli_stmt_store_result($stmt);


        if (mysqli_stmt_num_rows($stmt) == 1) {

          mysqli_stmt_bind_result($stmt, $id, $email, $password, $email_verified_at);
          if (mysqli_stmt_fetch($stmt)) {
            if ($email_verified_at !== null) {
              if (password_verify($password_lg, $password)) {


                $_SESSION["sid"] = $id;
                $_SESSION["email"] = $email;


                header("location: index.php");
              } else {

                $msg = "Invalid email or password.";
              }
            } else {
              $msg_ver = "Please verify your Email.";
            }
          }
        } else {

          $msg = "Invalid email or password.";
        }
      } else {
        $msg = "Oops! Something went wrong. Please try again later.";
      }


      mysqli_stmt_close($stmt);
    }
  }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <title>GARAGE92 | Login Page</title>
  <link href="img/favicon.ico" rel="icon">
  <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
  <link href="css/style.css" rel="stylesheet">
</head>

<body>
  <?php include_once('includes/header.php'); ?>


  <?php
  if (!empty($msg)) {
    echo '<div class="alert alert-danger">' . $msg . '</div>';
  }
  if (!empty($msg_ver)) {
    echo '<div class="alert alert-warning">' . $msg_ver . '</div>';
  }
  ?>

  <div class="container-fluid h-custom mt-5">
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class="col-md-9 col-lg-6 col-xl-5">
        <img src="https://mdbootstrap.com/img/Photos/new-templates/bootstrap-login-form/draw2.png" class="img-fluid d-none d-lg-block d-xxl-none d-xxl-block" alt="Sample image">
      </div>
      <div class="col-md-8 col-lg-6 col-xl-4 offset-xl-1">
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">

          <div class="form-group form-outline mb-4">
            <label class="form-label" for="email">Email address</label>
            <input type="email" id="email" name="email" class="form-control form-control-lg <?php echo (!empty($email_err)) ? 'is-invalid' : '';
                                                                                            ?>" value="<?php echo $emails;
                                                                                                        ?>" placeholder="Enter a valid email address" />
            <span class="invalid-feedback"><?php echo $email_err; ?></span>
          </div>

          <div class="form-group form-outline mb-3">
            <label class="form-label" for="password">Password</label>
            <input type="password" name="password" id="password" class="form-control form-control-lg <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?>" placeholder="Enter password" />
            <span class="invalid-feedback"><?php echo $password_err; ?></span>
          </div>

          <div class="d-flex justify-content-between align-items-center">
            <div class="form-check mb-0">

            </div>
            <a href="update-password/" class="text-body">Forgot password?</a>
          </div>

          <div class="text-center text-lg-start mt-4 pt-2">
            <div class="form-group">
              <input type="submit" class="btn btn-primary btn-lg rounded" style="padding-left: 2.5rem; padding-right: 2.5rem;" value="Login" />
            </div>
          </div>
          <p class="small fw-bold mt-2 pt-1 mb-0">Don't have an account? <a href="./register.php">Sign up now</a>.</p>
      </div>

      </form>
    </div>
  </div>
  </div>

  <?php include_once('includes/footer.php'); ?>

  <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script>
  <script src="lib/waypoints/waypoints.min.js"></script>
  <script src="js/main.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>

</html>