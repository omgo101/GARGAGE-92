<?php
session_start();

require './includes/config_admin.php';

$msg = "";
if (strlen($_SESSION['adid'] == 0)) {
    header('location:logout.php');
} else {

    if (isset($_POST['submit-add-mechanics'])) {
        $macname = $_POST['macname'];
        $mobno = $_POST['mobilenumber'];
        $email = $_POST['email'];
        $address = $_POST['macadd'];

        $query = mysqli_query($conn, "insert into  tblmechanics(FullName,MobileNumber,Email,Address) value('$macname','$mobno','$email','$address')");
        if ($query) {
            echo "<script>alert('Mechanic Details has been added.');</script>";
            echo "<script>window.location.href ='manage-mechanics.php'</script>";
        } else {
            $msg = "Something Went Wrong. Please try again";
        }
    }

?>

    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <title>GARAGE92 - Admin</title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
        <link href="css/styles.css" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
    </head>

    <body class="sb-nav-fixed">
        <?php include('./includes/headeradmin.php'); ?>
        <?php include('./includes/sidenavadmin.php'); ?>
        <div id="layoutSidenav_content">

            <main>
                <div class="container-fluid px-4">
                    <div class="content-wrapper">
                        <div class="container-fluid mt-4">

                            <div class="row">
                                <div class="col-12">
                                    <div class="card-box">
                                        <h4 class="m-t-0 header-title">Add Garage 92 Mechanics</h4>

                                        <div class="row">
                                            <div class="col-12">
                                                <div class="p-20">
                                                    <p style="font-size:16px; color:red" align="center">
                                                        <?php if ($msg) {
                                                            echo $msg;
                                                        }  ?> </p>

                                                    <form class="form-horizontal" role="form" method="post" name="submit-add-mechanics">

                                                        <div class="form-group row mt-2">
                                                            <label class="col-2 col-form-label" for="example-email">Mechanic Name</label>
                                                            <div class="col-10">
                                                                <input type="text" id="macname" name="macname" class="form-control" pattern="^[A-Za-z -]+$" title="Only Characters allowed" required="true">
                                                            </div>
                                                        </div>

                                                        <div class="form-group row mt-2">
                                                            <label class="col-2 col-form-label" for="example-email">Mechanic Contact Number</label>
                                                            <div class="col-10">
                                                                <input type="text" id="mobilenumber" name="mobilenumber" class="form-control" maxlength="10"  pattern="[0-9]{10}" title="please enter valid mobile number" required="true">
                                                            </div>
                                                        </div>

                                                        <div class="form-group row mt-2">
                                                            <label class="col-2 col-form-label" for="example-email">Mechanic Email</label>
                                                            <div class="col-10">
                                                                <input type="email" id="email" name="email" class="form-control" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" title="please enter valid email" required="true">
                                                            </div>
                                                        </div>


                                                        <div class="form-group row mt-2">
                                                            <label class="col-2 col-form-label" for="example-email">Mechanic Address</label>
                                                            <div class="col-10">
                                                                <input type="text" id="macadd" name="macadd" class="form-control" required="true">
                                                            </div>
                                                        </div>



                                                        <div class="form-group row mt-2">
                                                            <div class="col-12">
                                                                <p style="text-align: center;"> <button type="submit" name="submit-add-mechanics" class="btn btn-info btn-min-width mr-1 mb-1">Add</button></p>
                                                            </div>
                                                        </div>

                                                    </form>
                                                </div>
                                            </div>

                                        </div>

                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </main>
            <?php include('./includes/footeradmin.php'); ?>
        </div>
        </div>

        <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script>
            window.addEventListener('DOMContentLoaded', event => {

                const sidebarToggle = document.body.querySelector('#sidebarToggle');
                if (sidebarToggle) {
                    sidebarToggle.addEventListener('click', event => {
                        event.preventDefault();
                        document.body.classList.toggle('sb-sidenav-toggled');
                        localStorage.setItem('sb|sidebar-toggle', document.body.classList.contains('sb-sidenav-toggled'));
                    });
                }

            });
        </script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
    </body>

    </html>

<?php }  ?>