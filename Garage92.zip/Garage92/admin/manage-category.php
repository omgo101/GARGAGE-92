<?php
session_start();

require './includes/config_admin.php';

$msg = "";

if (strlen($_SESSION['adid'] == 0)) {
    header('location:logout.php');
} else {
    if (isset($_GET['id'])) {
        $eid = substr(base64_decode($_GET['id']), 0, -5);
        $query = mysqli_query($conn, "delete from tblcategory where ID='$eid'");
        if ($query) {
            echo "<script>alert('Category deleted.');</script>";
            echo "<script>window.location.href ='manage-category.php'</script>";
        } else {
            echo "<script>alert('Something Went Wrong. Please try again.');</script>";
        }
    }
?>

    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <title>GARAGE92 - Admin</title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
        <link href="css/styles.css" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
    </head>

    <body class="sb-nav-fixed">
        <?php include('./includes/headeradmin.php'); ?>
        <?php include('./includes/sidenavadmin.php'); ?>
        <div id="layoutSidenav_content">

            <main>
                <div class="container-fluid px-4">
                    <div class="content-wrapper">
                        <div class="container-fluid">

                            <div class="row mt-4">
                                <div class="col-12">
                                    <div class="card">
                                        <div class="card-header">
                                            <i class="fas fa-table me-1"></i>
                                            Manage Vehicle Category
                                        </div>

                                        <div class="row">
                                            <div class="col-12">
                                                <div class="p-20">
                                                    <table class="table datatablesSimple">
                                                        <thead>
                                                            <tr>
                                                                <th>S.NO</th>
                                                                <th>Category Name</th>

                                                                <th>Action</th>
                                                            </tr>
                                                        </thead>
                                                        <?php
                                                        $rno = mt_rand(10000, 99999);
                                                        $ret = mysqli_query($conn, "select * from tblcategory");
                                                        $cnt = 1;
                                                        while ($row = mysqli_fetch_array($ret)) {

                                                        ?>

                                                            <tr>
                                                                <td><?php echo $cnt; ?></td>
                                                                <td><?php echo $row['VehicleCat']; ?></td>
                                                                <td><a href="edit-category.php?editid=<?php echo base64_encode($row['ID'] . $rno); ?>">Edit</a> | <a href="manage-category.php?id=<?php echo base64_encode($row['ID'] . $rno); ?>" style="color:red;">Delete</a>


                                                            </tr>
                                                        <?php $cnt = $cnt + 1;
                                                        } ?>

                                                    </table>

                                                </div>
                                            </div>

                                        </div>

                                    </div>
                                </div>
                            </div>

                        </div>

                    </div>
                </div>
            </main>
            <?php include('./includes/footeradmin.php'); ?>
        </div>
        </div>

        <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script>
            window.addEventListener('DOMContentLoaded', event => {
                const sidebarToggle = document.body.querySelector('#sidebarToggle');
                if (sidebarToggle) {
                    sidebarToggle.addEventListener('click', event => {
                        event.preventDefault();
                        document.body.classList.toggle('sb-sidenav-toggled');
                        localStorage.setItem('sb|sidebar-toggle', document.body.classList.contains('sb-sidenav-toggled'));
                    });
                }

            });
        </script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
    </body>

    </html>

<?php }  ?>