<?php
session_start();

if (isset($_SESSION["adid"]) && $_SESSION["loggedin_admin"] === true) {
    header("location: index.php");
    exit;
}

require "./includes/config_admin.php";

$user = $password = "";
$user_err = $password_err = $login_err = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (empty(trim($_POST["username"]))) {
        $user_err = "Please enter Username.";
    } else {
        $user = trim($_POST["username"]);
    }

    if (empty(trim($_POST["password"]))) {
        $password_err = "Please enter your password.";
    } else {
        $pass = trim($_POST["password"]);
    }

    if (empty($user_err) && empty($password_err)) {
        $sql = "SELECT ID, AdminName, password FROM tbladmin WHERE AdminuserName = ?";

        if ($stmt = mysqli_prepare($conn, $sql)) {
            mysqli_stmt_bind_param($stmt, "s", $param_user);

            $param_user = $user;

            if (mysqli_stmt_execute($stmt)) {
                mysqli_stmt_store_result($stmt);

                if (mysqli_stmt_num_rows($stmt) == 1) {

                    mysqli_stmt_bind_result($stmt, $id, $adminname, $password);
                    if (mysqli_stmt_fetch($stmt)) {
                        if (password_verify($pass, $password)) {

                            session_start();

                            $_SESSION["loggedin_admin"] = true;
                            $_SESSION['adid'] = $id;
                            $_SESSION["username"] = $user;

                            header("location: index.php");
                        } else {
                            $msg = "Invalid username or password.";
                        }
                    }
                } else {
                    $msg = "Invalid username or password.";
                }
            } else {
                $msg = "Oops! Something went wrong. Please try again later.";
            }
            mysqli_stmt_close($stmt);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <title>Login - Admin</title>
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
</head>

<body class="bg-primary">
    <div id="layoutAuthentication">
        <div id="layoutAuthentication_content">
            <main>
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-5">
                            <div class="card shadow-lg border-0 rounded-lg mt-5">
                                <div class="card-header">
                                    <h3 class="text-center font-weight-light my-4">Login</h3>
                                </div>
                                <?php
                                if (!empty($msg)) {
                                    echo '<div class="alert alert-danger">' . $msg . '</div>';
                                }
                                ?>
                                <div class="card-body">
                                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                                        <div class="form-floating mb-3">
                                            <input class="form-control <?php echo (!empty($user_err)) ? 'is-invalid' : ''; ?>" id="inputEmail" type="text" name="username" placeholder="Username" />
                                            <label for="inputEmail">Username</label>
                                            <span class="invalid-feedback"><?php echo $user_err; ?></span>
                                        </div>
                                        <div class="form-floating mb-3">
                                            <input class="form-control <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?>" id="inputPassword" type="password" name="password" placeholder="Password" />
                                            <label for="inputPassword">Password</label>
                                            <span class="invalid-feedback"><?php echo $password_err; ?></span>
                                        </div>
                                        <div class="d-flex align-items-center justify-content-between mt-4 mb-0">
                                            <input type="submit" class="btn btn-primary rounded" value="Login" />
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
        <div id="layoutAuthentication_footer">
            <footer class="py-4 bg-light mt-auto">
                <div class="container-fluid px-4">
                    <div class="d-flex align-items-center justify-content-between small">
                        <div class="text-muted">Copyright &copy; GARAGE92 2022</div>
                        <!-- <div>
                            <a href="#">Privacy Policy</a>
                            &middot;
                            <a href="#">Terms &amp; Conditions</a>
                        </div> -->
                    </div>
                </div>
            </footer>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="js/scripts.js"></script>
</body>

</html>