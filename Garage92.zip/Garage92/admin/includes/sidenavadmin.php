<div id="layoutSidenav">
    <div id="layoutSidenav_nav">
        <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
            <div class="sb-sidenav-menu">
                <div class="nav">
                    <div class="sb-sidenav-menu-heading">Core</div>
                    <a class="nav-link" href="index.php">
                        <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                        Dashboard
                    </a>

                    <a class="nav-link collapsed" href="javascript: void(0);" data-bs-toggle="collapse" data-bs-target="#collapsePages1" aria-expanded="false" aria-controls="collapsePages1">
                        <div class="sb-nav-link-icon"></div>
                        Mechanics
                        <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                    </a>
                    <div class="collapse" id="collapsePages1" aria-labelledby="headingTwo" data-bs-parent="#sidenavAccordion1">
                        <nav class="sb-sidenav-menu-nested nav accordion" id="sidenavAccordionPages1">
                            <a class="nav-link collapsed" href="add-mechanics.php">
                                Add Mechanics
                            </a>
                            <a class="nav-link collapsed" href="manage-mechanics.php">
                                Manage Mechanics
                            </a>
                        </nav>
                    </div>


                    <a class="nav-link collapsed" href="javascript: void(0);" data-bs-toggle="collapse" data-bs-target="#collapsePages2" aria-expanded="false" aria-controls="collapsePages2">
                        <div class="sb-nav-link-icon"></div>
                        Vehicle Category
                        <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                    </a>
                    <div class="collapse" id="collapsePages2" aria-labelledby="headingTwo" data-bs-parent="#sidenavAccordion2">
                        <nav class="sb-sidenav-menu-nested nav accordion" id="sidenavAccordionPages2">
                            <a class="nav-link collapsed" href="add-category.php">
                                Add Category
                            </a>
                            <a class="nav-link collapsed" href="manage-category.php">
                                Manage Category
                            </a>
                        </nav>
                    </div>

                    <a class="nav-link collapsed" href="javascript: void(0);" data-bs-toggle="collapse" data-bs-target="#collapsePages3" aria-expanded="false" aria-controls="collapsePages3">
                        <div class="sb-nav-link-icon"></div>
                        Service Request
                        <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                    </a>
                    <div class="collapse" id="collapsePages3" aria-labelledby="headingTwo" data-bs-parent="#sidenavAccordion3">
                        <nav class="sb-sidenav-menu-nested nav accordion" id="sidenavAccordionPages3">
                            <a class="nav-link collapsed" href="pending-service.php">
                                New
                            </a>
                            <a class="nav-link collapsed" href="rejected-services.php">
                                Rejected
                            </a>
                        </nav>
                    </div>


                    <a class="nav-link collapsed" href="javascript: void(0);" data-bs-toggle="collapse" data-bs-target="#collapsePages4" aria-expanded="false" aria-controls="collapsePages4">
                        <div class="sb-nav-link-icon"></i></div>
                        Servicing
                        <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                    </a>
                    <div class="collapse" id="collapsePages4" aria-labelledby="headingTwo" data-bs-parent="#sidenavAccordion4">
                        <nav class="sb-sidenav-menu-nested nav accordion" id="sidenavAccordionPages4">
                            <a class="nav-link collapsed" href="pending-servicing.php">
                                Pending
                            </a>
                            <a class="nav-link collapsed" href="completed-service.php">
                                Completed
                            </a>
                        </nav>
                    </div>


                    <a class="nav-link" href="invoices.php">
                        <div class="sb-nav-link-icon"></div>
                        Generate Invoice
                    </a>
                    <a class="nav-link collapsed" href="javascript: void(0);" data-bs-toggle="collapse" data-bs-target="#collapsePages5" aria-expanded="false" aria-controls="collapsePages5">
                        <div class="sb-nav-link-icon"></div>
                        Customer Enquiry
                        <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                    </a>
                    <div class="collapse" id="collapsePages5" aria-labelledby="headingTwo" data-bs-parent="#sidenavAccordion5">
                        <nav class="sb-sidenav-menu-nested nav accordion" id="sidenavAccordionPages5">
                            <a class="nav-link collapsed" href="notrespond-enquiry.php">
                                Not Responded Enquiry
                            </a>
                            <a class="nav-link collapsed" href="respond-enquiry.php">
                                Responded Enquiry
                            </a>
                        </nav>
                    </div>

                </div>
            </div>
            <div class="sb-sidenav-footer">
                <div class="small">Logged in as:</div>
                <?php echo htmlspecialchars($_SESSION["username"]); ?>
            </div>
        </nav>
    </div>