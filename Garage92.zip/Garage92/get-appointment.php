<?php
session_start();

require "./includes/config.php";

if (!isset($_SESSION["sid"])) {
    header("location: login.php");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['submit'])) {
        $uid = $_SESSION['sid'];
        $category = $_POST['category'];
        $vehname = $_POST['vehiclename'];
        $vehmodel = $_POST['vehilemodel'];
        $vehbrand = $_POST['vehiclebrand'];
        $vehrego = $_POST['vehicleregno'];
        $vehservicedate = $_POST['servicedate'];
        $vehservicetime = $_POST['servicetime'];
        $deltype = $_POST['deltype'];
        $pickupadd = $_POST['pickupadd'];
        $sernumber = mt_rand(100000000, 999999999);

        $query = mysqli_query($conn, "insert into tblservicerequest(UserId,Category,ServiceNumber,VehicleName,VehicleModel,VehicleBrand,VehicleRegno,ServiceDate,ServiceTime,DeliveryType,PickupAddress) value('$uid','$category','$sernumber','$vehname','$vehmodel','$vehbrand','$vehrego','$vehservicedate','$vehservicetime','$deltype','$pickupadd')");
        if ($query) {
            echo "<script>alert('Your Service request have been sent successfully.');</script>";
            echo "<script>window.location.href = get-appointment.php'</script>";
        } else {
            echo "<script>alert('Something went wrong.Please try again.');</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>GARAGE92 | Service Booking</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <link href="img/favicon.ico" rel="icon">
    <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <link href="css/style.css" rel="stylesheet">
    <script type="text/javascript">
        $(document).ready(function() {
            $('#pickupaddress').hide();
            $('#deltype').change(function() {
                var v = $("#deltype").val();


                if (v == 'dropservice') {
                    $('#pickupaddress').hide();
                }

                if (v == 'pickupservice') {
                    $('#pickupaddress').show();
                }
            });
        });
    </script>
</head>

<body>

    <?php include_once('includes/header.php'); ?>

    <div class="page-header">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h2>Service Booking</h2>
                </div>
                <div class="col-12">
                    <a href="index.php">Home</a>
                    <a href="washing-plans.php">Price</a>
                </div>
            </div>
        </div>
    </div>

    <div class="price">
        <div class="container">
            <div class="section-header text-center">
                <p>Service Booking</p>
                <h2>Book your Vehicle Service Now</h2>
            </div>
            
            <div class="col-md-6 ml-auto mr-auto">
                <div class="price-item featured-item">
                    <div class="price-header">
                        <h3>GARAGE92</h3>
                        <h5><span>Affordable prices for Professional Services</span></h>
                    </div>
                   
                    <div class="price-footer">
                        <a class="btn btn-custom" data-toggle="modal" data-modal-id="myModel1" data-target="#myModal">Book Now</a>
                    </div>
                </div>
            </div>

        </div>

    </div>

    </div>

    <?php include_once('includes/footer.php'); ?>

    <div class="modal fade" id="myModal" role="dialog">
        <div class="modal-dialog rounded-0 modal-md modal-dialog-centered modal-xl" role="document" data-select2-id="13">
            <div class="modal-content  rounded-0" data-select2-id="12">
                <div class="modal-header">
                    <h5 class="modal-title">Fill the Service Request Form</h5>
                </div>
                <div class="modal-body">
                    <div class="container-fluid">
                        <form class="form-horizontal" role="form" method="post" name="submit">
                        
                            <div class="row">
                                <div class="col-12">
                                    <div class="card-box">
                                        <div class="row">
                                            <div class="col-12">
                                                <div class="p-20">

                                                    <div class="form-group row">
                                                        <label class="col-2 col-form-label">Category</label>
                                                        <div class="col-10">
                                                            <select name='category' id="category" class="form-control" required="true">
                                                                <option value="">Category</option>
                                                                <?php $link = mysqli_query($conn, "select * from tblcategory");
                                                                while ($row = mysqli_fetch_array($link)) {
                                                                ?>
                                                                    <option value="<?php echo $row['VehicleCat']; ?>"><?php echo $row['VehicleCat']; ?></option>
                                                                <?php } ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="form-group row">
                                                        <label class="col-2 col-form-label" for="example-email">Vehicle Name</label>
                                                        <div class="col-10">
                                                            <input type="text" id="vehiclename" name="vehiclename" class="form-control" placeholder="Vehicle Name" pattern="^[A-Za-z -]+$" title="Only Characters allowed" required="true">
                                                        </div>
                                                    </div>
                                                    <div class="form-group row">
                                                        <label class="col-2 col-form-label">Vehicle Model</label>
                                                        <div class="col-10">
                                                            <input type="text" class="form-control" name="vehilemodel" id="vehilemodel" pattern="[0-9]{4}" placeholder="Year" title="Valid Year" required="true">
                                                        </div>
                                                    </div>

                                                    <div class="form-group row">
                                                        <label class="col-2 col-form-label">Vehicle Brand</label>
                                                        <div class="col-10">
                                                            <input type="text" class="form-control" placeholder="Brand" name="vehiclebrand" id="vehiclebrand" pattern="[a-zA-Z ]+" title="Only Characters" required="true">
                                                        </div>
                                                    </div>
                                                    <div class="form-group row">
                                                        <label class="col-2 col-form-label">Vehicle Registration Number</label>
                                                        <div class="col-10">
                                                            <input type="text" class="form-control" name="vehicleregno" id="vehicleregno" placeholder="Example GA-07-XL-1234,GA-07-X-1234,GA-07-1234" pattern="^[A-Za-z]{2,3}(-\d{2}(-[A-Za-z]{1,2})?)?-\d{3,4}$" title="Enter Valid Registration Number" required="true">
                                                        </div>
                                                    </div>
                                                    <div class="form-group row">
                                                        <label class="col-2 col-form-label">Service Date</label>
                                                        <div class="col-10">
                                                            <input type="date" class="form-control" name="servicedate" id="servicedate" min="<?php echo date("Y-m-d"); ?>" required="true">
                                                        </div>
                                                    </div>

                                                    <div class="form-group row">
                                                        <label class="col-2 col-form-label">Service Time</label>
                                                        <div class="col-10">
                                                            <input type="time" class="form-control" name="servicetime" id="servicetime" min="08:00" max="18:00" required="true">
                                                        </div>
                                                    </div>

                                                    <div class="form-group row">
                                                        <label class="col-2 col-form-label">Delivery Type</label>
                                                        <div class="col-10">
                                                            <select name="deltype" id="deltype" required="true" class="form-control">
                                                                <option value="">Select</option>
                                                                <option value="pickupservice">Pickup Service</option>
                                                                <option value="dropservice">Drop Service</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="form-group row" id="pickupaddress">
                                                        <label class="col-2 col-form-label">Pickup Address</label>
                                                        <div class="col-10">
                                                            <input type="text" class="form-control" name="pickupadd" id="pickupadd">
                                                        </div>
                                                    </div>

                                                    <div class="form-group row">

                                                        <div class="col-12">
                                                            <p style="text-align: center;"> <button type="submit" name="submit" class="btn btn-info btn-min-width mr-1 mb-1">Submit</button></p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>

                                    </div>
                                </div>
                            </div>
                            <div class="w-100 d-flex justify-content-end mx-2">
                                <div class="col-auto">
                                    <button class="btn btn-dark btn-sm rounded-0" type="button" data-dismiss="modal">Close</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>

    <script src="js/main.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>

</html>